<?php   
  header('Location: affichage_blog.php');